Store soundpacks here.

A reboot is required to recognize them in the system.